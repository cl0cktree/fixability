INSTALLATION

Place the jsx script file in the ScriptUI Panels folder and run it from the WINDOW menu in After Effects.

OS X:  Adobe After Effects/Scripts/ScriptUI Panels

Windows:  Adobe After Effects\Support Files\Scripts\ScriptUI Panels
